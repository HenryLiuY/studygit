#!/bin/bash

scp ./page root@161.92.170.187:~/test/
scp ./*.qm root@161.92.170.187:~/test/
scp ./*.ts root@161.92.170.187:~/test/
exit 0

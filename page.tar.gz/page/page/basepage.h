#ifndef __BASEPAGE_H__FW4FIFOJW3IJF94G9FJIHFU8SDFIOSDMFOSDMFKLNMWEFNWS__
#define __BASEPAGE_H__FW4FIFOJW3IJF94G9FJIHFU8SDFIOSDMFOSDMFKLNMWEFNWS__

#include "pagedef.h"
#include <QWidget>
#include <QPoint>
#include <map>
#include <memory>

class BasePage : public QObject
{
    Q_OBJECT

public:
    explicit BasePage(const stPage& value);
    virtual ~BasePage();

    std::shared_ptr<QWidget> getWidget(WIDGET_DEF widgetEnum);

    virtual QPoint GetPosPoint(const QWidget* pWidget);
    virtual void showPage();
    virtual void closePage();
    virtual void hidePage();
    virtual void setWidgetsStatus(PAGE_ACTION action);
    virtual void setWidgetsParent(bool bValue, QWidget* parent = nullptr);

    stPage getStPage() { return m_page; }


protected:
    stPage m_page;
    std::map<WIDGET_DEF, std::shared_ptr<QWidget> > m_mapWidgets;

signals:
    void sigNotifyPageStatus(stPage page, PAGE_ACTION action);

protected:
    void setWidgetPos();

//    void hideEvent(QHideEvent* event);
//    void showEvent(QHideEvent* event);

    void sentNotifySigPageStatus(PAGE_ACTION action);

};


#endif // __BASEPAGE_H__FW4FIFOJW3IJF94G9FJIHFU8SDFIOSDMFOSDMFKLNMWEFNWS__

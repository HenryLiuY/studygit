#include "widgetManager.h"
#include <assert.h>
#include <QDebug>

WidgetManager* WidgetManager::m_pInstance = nullptr;
std::mutex WidgetManager::m_mutex;

WidgetManager::WidgetManager()
    :m_Mother(new QWidget)
{
    assert(m_Mother);
    m_Mother->resize(SCREEN_WIDTH, SCREEN_HEIGHT);
    m_Mother->setWindowFlags(Qt::FramelessWindowHint);
    m_Mother->show();
}

WidgetManager::~WidgetManager()
{
    mapClear();

    if(m_Mother)
    {
        delete m_Mother;
        m_Mother = nullptr;
    }


    DestroyInstance();
}

WidgetManager* WidgetManager::GetInstance()
{
    if(!m_pInstance)
    {
        std::lock_guard<std::mutex> locker(m_mutex);
        if(!m_pInstance)
        {
            m_pInstance = new WidgetManager();
        }
    }
    return m_pInstance;
}

void WidgetManager::DestroyInstance()
{
    if(m_pInstance)
    {
        std::lock_guard<std::mutex> locker(m_mutex);
        if(m_pInstance)
        {
            delete m_pInstance;
            m_pInstance = nullptr;
        }
    }
}

void WidgetManager::mapClear()
{
    QWriteLocker wlock(&m_rwlock);
    for(IT it = m_mapWidgets.begin(); it != m_mapWidgets.end(); ++it)
    {
        while(it->second.use_count() > 0)
        {
            it->second.reset();
        }
    }
    m_mapWidgets.clear();
}

bool WidgetManager::isExist(WIDGET_DEF eWidget)
{
    QReadLocker rlock(&m_rwlock);
    if(m_mapWidgets.find(eWidget) == m_mapWidgets.end())
    {
        return false;
    }

    return true;
}

std::shared_ptr<QWidget> WidgetManager::registerWidget(WIDGET_DEF eWidget)
{
    if(!isExist(eWidget))
    {
        QWriteLocker wlock(&m_rwlock);
        m_mapWidgets[eWidget] = std::make_shared<QWidget>();
        m_mapWidgets[eWidget]->setParent(m_Mother);
        m_mapWidgets[eWidget]->setWindowFlags(Qt::FramelessWindowHint);
        m_mapWidgets[eWidget]->hide();
    //    m_mapWidgets[eWidget]->setAttribute(Qt::WA_DeleteOnClose, false);
    }

    return m_mapWidgets[eWidget];
}

void WidgetManager::unregisterWidget(WIDGET_DEF eWidget)
{
    QWriteLocker wlock(&m_rwlock);
    if(m_mapWidgets.find(eWidget) == m_mapWidgets.end())
    {
        return;
    }

    m_mapWidgets[eWidget].reset();
    m_mapWidgets.erase(eWidget);
}

//bool WidgetManager::resetWidget(WIDGET_DEF eWidget)
//{
//    QWriteLocker wlock(&m_rwlock);
//    if(m_mapWidgets.find(eWidget) == m_mapWidgets.end())
//    {
//        return false;
//    }

//    m_mapWidgets[eWidget].reset();

//    if(m_mapWidgets[eWidget].use_count() <= 1)
//    {
//        m_mapWidgets[eWidget].reset();
//        m_mapWidgets.erase(eWidget);
//    }

//    return true;
//}

std::shared_ptr<QWidget> WidgetManager::getWidgetFromEnum(WIDGET_DEF eWidget)
{
    QReadLocker rlock(&m_rwlock);
    return m_mapWidgets[eWidget];
}

unsigned int WidgetManager::getSize()
{
    QReadLocker rlock(&m_rwlock);
    return m_mapWidgets.size();
}


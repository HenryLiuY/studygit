#ifndef __WIDGETMANAGER_H__WOEJFOWEJFEJFFPSK34494898484FJEOFJDFJSDFSD
#define __WIDGETMANAGER_H__WOEJFOWEJFEJFFPSK34494898484FJEOFJDFJSDFSD
#include <map>
#include <mutex>
#include "pagedef.h"
#include <QReadWriteLock>
#include <memory>
#include <QWidget>


class WidgetManager : public QObject
{
    Q_OBJECT

private:
    WidgetManager();
    ~WidgetManager();

    void mapClear();

    //private to avoid memory leak
    std::shared_ptr<QWidget> getWidgetFromEnum(WIDGET_DEF eWidget);

private:
    std::map<WIDGET_DEF, std::shared_ptr<QWidget> > m_mapWidgets;
    typedef std::map<WIDGET_DEF, std::shared_ptr<QWidget> >::iterator IT;
    typedef std::map<WIDGET_DEF, std::shared_ptr<QWidget> >::const_iterator CIT;

    QWidget* m_Mother;

    static WidgetManager* m_pInstance;
    static std::mutex m_mutex;

    QReadWriteLock m_rwlock;

public:
    unsigned int getSize();
    static WidgetManager* GetInstance();
    void DestroyInstance();

    bool isExist(WIDGET_DEF eWidget);
    std::shared_ptr<QWidget> registerWidget(WIDGET_DEF eWidget);
    void unregisterWidget(WIDGET_DEF eWidget);

//    bool resetWidget(WIDGET_DEF eWidget);
};

#endif // __WIDGETMANAGER_H__WOEJFOWEJFEJFFPSK34494898484FJEOFJDFJSDFSD

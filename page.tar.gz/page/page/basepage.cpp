#include "basepage.h"
#include "widgetManager.h"
#include "pageManager.h"
#include <QVariant>
#include <QDebug>
#include <QCloseEvent>
#include <QHideEvent>

BasePage::BasePage(const stPage& value)
    :m_page(value)
{
    m_mapWidgets[m_page.eTOP] = WidgetManager::GetInstance()->registerWidget(m_page.eTOP);
    m_mapWidgets[m_page.eFNC] = WidgetManager::GetInstance()->registerWidget(m_page.eFNC);
    m_mapWidgets[m_page.eBTM] = WidgetManager::GetInstance()->registerWidget(m_page.eBTM);


    pageManager::GetInstance()->RegisterPage(m_page, this);

    connect(this, SIGNAL(sigNotifyPageStatus(stPage, PAGE_ACTION)), pageManager::GetInstance(), SLOT(NotifyPageStatus(stPage, PAGE_ACTION)));
}

BasePage::~BasePage()
{    
    pageManager::GetInstance()->unRegisterPage(m_page);

    for(auto& elem : m_mapWidgets)
    {
        if(elem.second.use_count() <= 2)
        {
            WidgetManager::GetInstance()->unregisterWidget(elem.first);
        }
        elem.second.reset();

    }
    m_mapWidgets.clear();
}

std::shared_ptr<QWidget> BasePage::getWidget(WIDGET_DEF widgetEnum)
{
    return m_mapWidgets[widgetEnum];
}

void BasePage::setWidgetsStatus(PAGE_ACTION action)
{    
    for(auto& elem : m_mapWidgets)
    {
        switch(action)
        {
            case PAGE_ACTION::PAGESHOW:
                elem.second->show();
                break;
            case PAGE_ACTION::PAGEHIDE:
                elem.second->hide();
                break;
            case PAGE_ACTION::PAGECLOSE:
                if(elem.second.use_count() <= 2)
                {
                    WidgetManager::GetInstance()->unregisterWidget(elem.first);
                }
                elem.second.reset();
                break;
            default:
                break;
        }
    }
}

void BasePage::showPage()
{
    stPage page = pageManager::GetInstance()->getCurrentPage();
    if(page != m_page)
    {
        sentNotifySigPageStatus(PAGE_ACTION::PAGESHOW);
        setWidgetsStatus(PAGE_ACTION::PAGESHOW);
        setWidgetPos();
    }
}

void BasePage::closePage()
{
    setWidgetsStatus(PAGE_ACTION::PAGECLOSE);
    sentNotifySigPageStatus(PAGE_ACTION::PAGECLOSE);
}

void BasePage::hidePage()
{
    stPage page = pageManager::GetInstance()->getCurrentPage();
    if(page == m_page)
    {
        setWidgetsStatus(PAGE_ACTION::PAGEHIDE);
        sentNotifySigPageStatus(PAGE_ACTION::PAGEHIDE);
    }
}

QPoint BasePage::GetPosPoint(const QWidget* pWidget)
{
    QVariant var = pWidget->property(AREA_POS.toLatin1().data());
    if(var.isValid())
    {
        return var.toPoint();
    }

    return QPoint(0, 0);
}

void BasePage::setWidgetPos()
{
    for(auto& elem : m_mapWidgets)
    {
        QPoint position = GetPosPoint(elem.second.get());
        elem.second->move(position);
    }
}

void BasePage::setWidgetsParent(bool bValue, QWidget* parent)
{
    for(auto& elem : m_mapWidgets)
    {
        if(bValue)
        {
            if(parent != nullptr && elem.second->parent() != parent)
            {
                elem.second->setParent(parent);
                setWidgetPos();
            }
        }
        else
        {
            elem.second->setParent(nullptr);
        }
    }
}

void BasePage::sentNotifySigPageStatus(PAGE_ACTION action)
{
        emit(sigNotifyPageStatus(m_page, action));
}


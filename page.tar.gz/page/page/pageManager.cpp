#include "pageManager.h"
#include "factory.h"
#include <QDebug>

pageManager* pageManager::m_pInstance = nullptr;
std::mutex pageManager::m_mutex;

pageManager::pageManager()
{

}

pageManager::~pageManager()
{
    DestroyInstance();
}

stPage pageManager::getCurrentPage()
{
    QReadLocker rlocker(&m_rwlock_list);
    if(m_listSequence.size() > 0)
    {
        return m_listSequence.back();
    }
    else
    {
        stPage page;
        return page;
    }
}

bool pageManager::findPageInList(stPage page)
{
    bool bExistInList = false;
    if(m_listSequence.size() > 0)
    {
        for(auto listPage : m_listSequence)
        {
            if(listPage == page)
            {
                bExistInList = true;
            }
        }
    }
    return bExistInList;
}


bool pageManager::setCurrentPage(stPage page)
{
    if(1)
    {
        QWriteLocker wlocker(&m_rwlock_map);
        CIT_MAP cit = m_mapPages.find(page);
        if(cit == m_mapPages.end())
        {
            return false;
        }
    }

    if(1)
    {
        QWriteLocker wlocker(&m_rwlock_list);
//        if(m_listSequence.size() > 0 && m_listSequence.back() != page)
//        {
//            switch(prePageAction)
//            {
//                case PAGE_ACTION::PAGECLOSE:
//                    break;
//                case PAGE_ACTION::PAGEHIDE:
//                    break;
//                default:
//                    break;
//            }
//        }

        reSequence(page);
    }

    return true;
}

void pageManager::NotifyPageStatus(stPage page, PAGE_ACTION action)
{
    //qDebug() << "pageManager Notify " << (int)page << " " << (int)action << "listsize: " << m_listSequence.size();

    switch (action)
    {
        case PAGE_ACTION::PAGESHOW:
            setCurrentPage(page);
            break;
        case PAGE_ACTION::PAGEHIDE:
            if(m_listSequence.size() >= 2)
            {
                stPage currentPage;
                if(1)
                {
                    QWriteLocker wlocker(&m_rwlock_list);
                    m_listSequence.pop_back();
                    currentPage = m_listSequence.back();
                    m_listSequence.push_back(page);
                }
                m_mapPages[currentPage]->showPage();
            }
            break;
        case PAGE_ACTION::PAGECLOSE:
            if(1)
            {

                QWriteLocker wlocker(&m_rwlock_list);
                m_listSequence.pop_back();
            }

            if(m_listSequence.size() > 0)
            {
                m_mapPages[m_listSequence.back()]->showPage();
            }
            break;
        default:
            break;
    }

}

void pageManager::RegisterPage(stPage page, BasePage* pBasePage)
{
    QWriteLocker wlocker(&m_rwlock_map);
    CIT_MAP cit = m_mapPages.find(page);
    if(cit == m_mapPages.end())
    {
        m_mapPages[page] = pBasePage;
    }
}

void pageManager::unRegisterPage(stPage page)
{   
    if(1)
    {
        QWriteLocker wlocker(&m_rwlock_list);
        if(findPageInList(page))
        {
            m_listSequence.remove(page);
        }
    }

    if(1)
    {
        QWriteLocker wlocker(&m_rwlock_map);
        IT_MAP cit = m_mapPages.find(page);
        if(cit != m_mapPages.end())
        {
            m_mapPages.erase(page);
        }
    }
}

pageManager* pageManager::GetInstance()
{
    if(!m_pInstance)
    {
        std::lock_guard<std::mutex> locker(m_mutex);
        if(!m_pInstance)
        {
            m_pInstance = new pageManager();
        }
    }
    return m_pInstance;
}

void pageManager::clearList()
{
    QWriteLocker wlocker(&m_rwlock_list);
    m_listSequence.clear();
}

void pageManager::clearMap()
{
    QWriteLocker wlocker(&m_rwlock_map);

//    for(auto& elem : m_mapPages)
//    {
//        delete elem.second;
//        elem.second = nullptr;
//    }
    m_mapPages.clear();
}

void pageManager::DestroyInstance()
{
    clearMap();
    clearList();

    if(m_pInstance)
    {
        std::lock_guard<std::mutex> locker(m_mutex);
        if(m_pInstance)
        {
            delete m_pInstance;
            m_pInstance = nullptr;
        }
    }
}

void pageManager::reSequence(stPage page)
{
    if(findPageInList(page))
    {
        m_listSequence.remove(page);
    }

    m_listSequence.push_back(page);
}

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>TopPage</name>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="295"/>
        <source>Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="296"/>
        <source>top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="299"/>
        <location filename="UI_File/ui_TopPage.h" line="302"/>
        <source>Standard 12 leads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="300"/>
        <source>Standard 18 leads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="303"/>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="304"/>
        <source>Archive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="308"/>
        <source>Monteorello, S.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="309"/>
        <source>MRN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="310"/>
        <source>3424-27843</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="311"/>
        <source>62yrs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="312"/>
        <source>Female</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="313"/>
        <source>247 lbs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="318"/>
        <location filename="UI_File/ui_TopPage.h" line="324"/>
        <source>Dr.Brandon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="319"/>
        <source>My account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="320"/>
        <source>System setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="321"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI_File/ui_TopPage.h" line="322"/>
        <source>Log out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pageM</name>
    <message>
        <location filename="pagem.ui" line="14"/>
        <source>pageM</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

#ifndef PAGEM_H__EOFIJFEWODSJFIOJHGEWIOHWEFOWEJFLFWEOIJFWEOF32332
#define PAGEM_H__EOFIJFEWODSJFIOJHGEWIOHWEFOWEJFLFWEOIJFWEOF32332

#include <QWidget>
#include <map>
#include <list>
#include <mutex>
#include <QReadWriteLock>
#include "basepage.h"
#include "pagedef.h"
#include "widgetManager.h"


class pageManager : public QObject
{
    Q_OBJECT

//    enum class PAGEACTION
//    {
//        HIDE_EXIST_LIST,
//        REMOVE_FROM_LIST
//    };

public slots:
    void NotifyPageStatus(stPage page, PAGE_ACTION action);

public:
    void RegisterPage(stPage page, BasePage* pBasePage);
    void unRegisterPage(stPage page);

    bool setCurrentPage(stPage page/*, PAGE_ACTION prePageAction = PAGE_ACTION::MAX_UNDEF*/);
    stPage getCurrentPage();

//    void removePage(stPage page);


private:
    explicit pageManager();
    virtual ~pageManager();

    void reSequence(stPage page);
    void clearMap();
    void clearList();
    bool findPageInList(stPage page);

public:
    static pageManager* GetInstance();
    void DestroyInstance();

private:
    static pageManager* m_pInstance;
    static std::mutex m_mutex;

    QReadWriteLock m_rwlock_map;
    QReadWriteLock m_rwlock_list;

private:
    std::map<stPage, BasePage*> m_mapPages;
    typedef std::map<stPage, BasePage*>::const_iterator CIT_MAP;
    typedef std::map<stPage, BasePage*>::iterator IT_MAP;

    std::list<stPage> m_listSequence;
    typedef std::list<stPage>::const_iterator CIT_LIST;
    typedef std::list<stPage>::iterator IT_LIST;
};

#endif // PAGEM_H__EOFIJFEWODSJFIOJHGEWIOHWEFOWEJFLFWEOIJFWEOF32332

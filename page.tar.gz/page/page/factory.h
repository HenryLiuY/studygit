#ifndef FACTORY_H_EOFJOJOJLSOIJIWEUFPKEK4489LKM8WE9JIOSFODFJSDJDFA
#define FACTORY_H_EOFJOJOJLSOIJIWEUFPKEK4489LKM8WE9JIOSFODFJSDJDFA

#include "basepage.h"
#include "widgetManager.h"

template<class ui_TOPWidget, class ui_FNCWidget, class ui_BTMWidget>
class Factory
{

public:
    Factory()
    {

    }

    ~Factory()
    {

    }

    void CombineWidget(BasePage* pBasePage/*, const stPage& keys*/)
    {
        ui_TOPWidget* pUITop = new ui_TOPWidget();
        pUITop->setupUi(pBasePage->getWidget(pBasePage->getStPage().eTOP).get());

        ui_FNCWidget* pUIFnc = new ui_FNCWidget();
        pUIFnc->setupUi(pBasePage->getWidget(pBasePage->getStPage().eFNC).get());

        ui_BTMWidget* pUIBtm = new ui_BTMWidget();
        pUIBtm->setupUi(pBasePage->getWidget(pBasePage->getStPage().eBTM).get());
    }
};


#endif // FACTORY_H_EOFJOJOJLSOIJIWEUFPKEK4489LKM8WE9JIOSFODFJSDJDFA


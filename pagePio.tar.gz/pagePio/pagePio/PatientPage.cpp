#include "PatientPage.h"
#include <QVariant>
#include "UI_File/ui_TopPage.h"
#include "UI_File/ui_PatientPage.h"
#include "UI_File/ui_BtmPage.h"
#include "./include/pageManager/pagedef.h"
#include "./include/pageManager/pageManager.h"
#include <QPoint>
#include "./include/pageManager/widgetManager.h"
#include <QDebug>


PatientPage::PatientPage()
    :BasePage(stPage(WIDGET_DEF::TOP_MAINPAGE,
                     WIDGET_DEF::FNC_PATIENT,
                     WIDGET_DEF::BTM_PATIENT))
{
    Factory<Ui::TopPage, Ui::PatientPage, Ui::BtmPage>().CombineWidget(this);
}


PatientPage::~PatientPage()
{
    qDebug() << "~PatientPage(): ================="<< "=====size: " << WidgetManager::GetInstance()->getSize();
}




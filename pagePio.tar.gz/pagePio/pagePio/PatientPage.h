#ifndef PATIENTPAGE_H_DSAFLKDSJFWOIE232433I9FJSIFJWEOIFWEFIWEFWEF
#define PATIENTPAGE_H_DSAFLKDSJFWOIE232433I9FJSIFJWEOIFWEFIWEFWEF

//#include "pagedef.h"

#include <QWidget>
#include <QPoint>
#include "./include/pageManager/factory.h"
#include "./include/pageManager/basepage.h"
#include <QCloseEvent>

namespace Ui {
    class TopPage;
    class PatientPage;
    class BtmPage;
}

class PatientPage: public BasePage
{
    Q_OBJECT
public:
    explicit PatientPage();
    ~PatientPage();
};

#endif // PATIENTPAGE_H_DSAFLKDSJFWOIE232433I9FJSIFJWEOIFWEFIWEFWEF

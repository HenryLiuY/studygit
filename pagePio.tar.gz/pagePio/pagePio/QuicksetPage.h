#ifndef QUICKSET_H_FOEWJEOJFWEOJFOJSDFSDNFNIBGWEPOWEPOO2332P23OPJ
#define QUICKSET_H_FOEWJEOJFWEOJFOJSDFSDNFNIBGWEPOWEPOO2332P23OPJ


#include <QWidget>
#include <QPoint>
#include "./include/pageManager/factory.h"
#include "./include/pageManager/basepage.h"
#include <QCloseEvent>

namespace Ui {
    class TopPage;
    class QuickSetPage;
    class BtmPage;
}

class QuickSetPage: public BasePage
{
    Q_OBJECT
public:
    explicit QuickSetPage();
    ~QuickSetPage();
};

#endif // QUICKSET_H_FOEWJEOJFWEOJFOJSDFSDNFNIBGWEPOWEPOO2332P23OPJ

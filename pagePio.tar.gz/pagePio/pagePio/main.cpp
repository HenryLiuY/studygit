#include "PatientPage.h"
#include "QuicksetPage.h"
#include <QApplication>
#include <QTranslator>
#include <QDebug>
#include "./include/pageManager/widgetManager.h"
#include "./include/pageManager/factory.h"

#include "./include/pageManager/pageManager.h"
#include "./UI_File/ui_mainpage.h"

#include <unistd.h>


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QTranslator* pTranslator = new QTranslator(&app);
    pTranslator->load("MB_CN.qm");
    app.installTranslator(pTranslator);

    PatientPage* pPatientPage= new PatientPage();
    if(pPatientPage)
    {
        pPatientPage->showPage();
        qDebug() << "BTM usr_count: " << pPatientPage->getWidget(WIDGET_DEF::BTM_PATIENT).use_count();
    }


    QuickSetPage* pQuickSetPage= new QuickSetPage();
    if(pQuickSetPage)
    {
        pQuickSetPage->showPage();


        qDebug() << "BTM usr_count: " << pQuickSetPage->getWidget(WIDGET_DEF::BTM_PATIENT).use_count();
//        pQuickSetPage->close();

                qDebug() << "BTM usr_count: " << pQuickSetPage->getWidget(WIDGET_DEF::BTM_PATIENT).use_count();
    }


//    if(pQuickSetPage)
//    {
//        delete pQuickSetPage;
//        pQuickSetPage = nullptr;
//    }

//            qDebug() << "BTM usr_count: " << pPatientPage->getWidget(WIDGET_DEF::BTM_PATIENT).use_count();

    return app.exec();
}

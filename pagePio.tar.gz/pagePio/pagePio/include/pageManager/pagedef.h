#ifndef __PAGEDEF_H_FEWFWEFWEFJO3I23950499GJIERJGOJ__
#define __PAGEDEF_H_FEWFWEFWEFJO3I23950499GJIERJGOJ__
#include "pagedef.h"
#include <QString>

#define SCREEN_WIDTH (640)
#define SCREEN_HEIGHT (480)

const QString AREA_POS = "AreaPos";


enum WIDGET_DEF : int
{
    TOP_MAINPAGE = 1001,
    FNC_MAINPAGE = 2001,
    FNC_PATIENT  = 2002,
    FNC_QUICKSET = 2003,
    BTM_MAINPAGE = 3001,
    BTM_RYHTHM   = 3001,
    BTM_PATIENT  = 3003,
    MAX_WIDGETDEF_UNDEF = -1
};

enum class PAGE_ACTION
{
    PAGECLOSE,
    PAGEHIDE,
    PAGESHOW,
    MAX_UNDEF
};

typedef struct PageStruct
{
    WIDGET_DEF eTOP;
    WIDGET_DEF eFNC;
    WIDGET_DEF eBTM;

//    PageStruct()
//    {
//        eTOP = WIDGET_DEF::MAX_WIDGETDEF_UNDEF;
//        eFNC = WIDGET_DEF::MAX_WIDGETDEF_UNDEF;
//        eBTM = WIDGET_DEF::MAX_WIDGETDEF_UNDEF;
//    }

    PageStruct(WIDGET_DEF top = WIDGET_DEF::MAX_WIDGETDEF_UNDEF, WIDGET_DEF fnc = WIDGET_DEF::MAX_WIDGETDEF_UNDEF, WIDGET_DEF btm = WIDGET_DEF::MAX_WIDGETDEF_UNDEF)
    {
        eTOP = top;
        eFNC = fnc;
        eBTM = btm;
    }

    inline bool operator!=(const PageStruct other) const
    {
        return ((other.eTOP != this->eTOP)
                || (other.eFNC != this->eFNC)
                || (other.eBTM != this->eBTM))? true : false;
    }

    inline bool operator==(const PageStruct other) const
    {
        return ((other.eTOP == this->eTOP)
                && (other.eFNC == this->eFNC)
                && (other.eBTM == this->eBTM))? true : false;
    }

    inline bool operator<(const PageStruct other) const
    {
        return ((other.eTOP > this->eTOP)
                || (other.eFNC > this->eFNC)
                || (other.eBTM > this->eBTM))? true : false;
    }

}stPage;

//enum class PAGE_DEF : int
//{
//    PAGE_MAINPAGE = 0, // TOP_MAINPAGE|FNC_MAINPAGE|BTM_MAINPAGE
//    PAGE_PATIENT = 1,  // TOP_MAINPAGE|FNC_PATIENT|BTM_PATIENT
//    PAGE_QUICKSET = 2, // TOP_MAINPAGE|FNC_QUICKSET|BTM_PATIENT
//    MAX_PAGEDEF_UNDEF = -1
//};


#endif // __PAGEDEF_H_FEWFWEFWEFJO3I23950499GJIERJGOJ__


/********************************************************************************
** Form generated from reading UI file 'BtmPage.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef BTMPAGE_H
#define BTMPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BtmPage
{
public:
    QToolButton *toolButton;
    QToolButton *btnQuickset;
    QComboBox *comboBox;
    QLabel *label_3;
    QWidget *line;
    QPushButton *stopPrint;
    QPushButton *startPrint;
    QPushButton *patientID;
    QPushButton *leadSelect;

    void setupUi(QWidget *BtmPage)
    {
        if (BtmPage->objectName().isEmpty())
            BtmPage->setObjectName(QStringLiteral("BtmPage"));
        BtmPage->resize(640, 54);
        BtmPage->setStyleSheet(QLatin1String("background-color:  #000000;\n"
"border: none;\n"
"\n"
"	font-size: 12px;"));
        BtmPage->setProperty("AreaPos", QVariant(QPoint(0, 426)));
        toolButton = new QToolButton(BtmPage);
        toolButton->setObjectName(QStringLiteral("toolButton"));
        toolButton->setGeometry(QRect(20, 12, 30, 30));
        QIcon icon;
        icon.addFile(QStringLiteral(":/res/load-map1x.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon);
        toolButton->setIconSize(QSize(30, 30));
        btnQuickset = new QToolButton(BtmPage);
        btnQuickset->setObjectName(QStringLiteral("btnQuickset"));
        btnQuickset->setGeometry(QRect(70, 10, 45, 28));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/res/quickset1x.png"), QSize(), QIcon::Normal, QIcon::Off);
        btnQuickset->setIcon(icon1);
        btnQuickset->setIconSize(QSize(42, 29));
        comboBox = new QComboBox(BtmPage);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(472, 4, 160, 42));
        QFont font;
        comboBox->setFont(font);
#ifndef QT_NO_TOOLTIP
        comboBox->setToolTip(QStringLiteral(""));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        comboBox->setStatusTip(QStringLiteral(""));
#endif // QT_NO_STATUSTIP
#ifndef QT_NO_WHATSTHIS
        comboBox->setWhatsThis(QStringLiteral(""));
#endif // QT_NO_WHATSTHIS
#ifndef QT_NO_ACCESSIBILITY
        comboBox->setAccessibleName(QStringLiteral(""));
#endif // QT_NO_ACCESSIBILITY
#ifndef QT_NO_ACCESSIBILITY
        comboBox->setAccessibleDescription(QStringLiteral(""));
#endif // QT_NO_ACCESSIBILITY
        comboBox->setStyleSheet(QLatin1String("QComboBox{\n"
"	padding-left: 39px;\n"
"	padding-top: 3px;\n"
"	background-color: rgb(235, 159, 0);\n"
"	color: #ffffff;\n"
"	border-radius: 2px;\n"
"}\n"
"\n"
"QComboBox::down-arrow{\n"
"image: url(:/res/blueBtn1x.png);\n"
"}\n"
"\n"
"QComboBox::drop-down{\n"
"	padding-right: 3px;\n"
"	border-radius: 2px;\n"
"	border: none;\n"
"	width: 26px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView::item{\n"
"	padding-left: 5px;\n"
"	height: 42px;\n"
"	min-height: 42px;\n"
"	width: 160px;\n"
"	min-width: 160px;\n"
"	color: rgba(214, 214, 214, 0.8);\n"
"	border-color: #383838;\n"
"	background-color: #383838;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView::item:selected{\n"
"	padding-left: 5px;\n"
"	border-color: rgba(120, 120, 120, 0.35);\n"
"	color: #d6d6d6;\n"
"	background-color: rgba(120, 120, 120);\n"
"	border: none;\n"
"}"));
        label_3 = new QLabel(BtmPage);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(484, 17, 18, 16));
        label_3->setStyleSheet(QLatin1String("background-image: url(:/res/fill-1x.png);\n"
"background-repeat: no-repeat;\n"
"	background-color: rgb(235, 159, 0);"));
        line = new QWidget(BtmPage);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(597, 4, 2, 42));
        line->setStyleSheet(QStringLiteral("	background-color: rgb(200, 200, 0);"));
        stopPrint = new QPushButton(BtmPage);
        stopPrint->setObjectName(QStringLiteral("stopPrint"));
        stopPrint->setGeometry(QRect(373, 4, 90, 42));
        stopPrint->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color: rgb(235, 159, 0);\n"
"	color: #ffffff;\n"
"	border-radius: 2px;\n"
"}"));
        startPrint = new QPushButton(BtmPage);
        startPrint->setObjectName(QStringLiteral("startPrint"));
        startPrint->setGeometry(QRect(275, 4, 90, 42));
        startPrint->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color: rgb(235, 159, 0);\n"
"	color: #ffffff;\n"
"	border-radius: 2px;\n"
"}"));
        patientID = new QPushButton(BtmPage);
        patientID->setObjectName(QStringLiteral("patientID"));
        patientID->setGeometry(QRect(208, 4, 51, 42));
        patientID->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color: rgb(235, 159, 0);\n"
"	color: #ffffff;\n"
"	border-radius: 2px;\n"
"}"));
        leadSelect = new QPushButton(BtmPage);
        leadSelect->setObjectName(QStringLiteral("leadSelect"));
        leadSelect->setGeometry(QRect(140, 4, 51, 42));
        leadSelect->setStyleSheet(QLatin1String("QPushButton{\n"
"	background-color: rgb(235, 159, 0);\n"
"	color: #ffffff;\n"
"	border-radius: 2px;\n"
"}"));

        retranslateUi(BtmPage);

        comboBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(BtmPage);
    } // setupUi

    void retranslateUi(QWidget *BtmPage)
    {
        BtmPage->setWindowTitle(QApplication::translate("BtmPage", "BtmPage", Q_NULLPTR));
        BtmPage->setProperty("Category", QVariant(QApplication::translate("BtmPage", "btm", Q_NULLPTR)));
        toolButton->setText(QApplication::translate("BtmPage", "Lead Map", Q_NULLPTR));
        btnQuickset->setText(QApplication::translate("BtmPage", "...", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("BtmPage", "Acquire ECG", Q_NULLPTR)
         << QApplication::translate("BtmPage", "Disclose", Q_NULLPTR)
         << QApplication::translate("BtmPage", "Rhythm", Q_NULLPTR)
        );
        comboBox->setCurrentText(QApplication::translate("BtmPage", "Acquire ECG", Q_NULLPTR));
        label_3->setText(QString());
        stopPrint->setText(QApplication::translate("BtmPage", "Stop", Q_NULLPTR));
        startPrint->setText(QApplication::translate("BtmPage", "Start", Q_NULLPTR));
        patientID->setText(QApplication::translate("BtmPage", "ID", Q_NULLPTR));
        leadSelect->setText(QApplication::translate("BtmPage", "Leads", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class BtmPage: public Ui_BtmPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // BTMPAGE_H

/********************************************************************************
** Form generated from reading UI file 'pagem.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGEM_H
#define UI_PAGEM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_pageM
{
public:

    void setupUi(QWidget *pageM)
    {
        if (pageM->objectName().isEmpty())
            pageM->setObjectName(QStringLiteral("pageM"));
        pageM->resize(640, 480);
        pageM->setAutoFillBackground(false);
        pageM->setStyleSheet(QLatin1String("QWidget{\n"
"	background-color: rgb(0, 0, 0);\n"
"}"));

        retranslateUi(pageM);

        QMetaObject::connectSlotsByName(pageM);
    } // setupUi

    void retranslateUi(QWidget *pageM)
    {
        pageM->setWindowTitle(QApplication::translate("pageM", "pageM", 0));
    } // retranslateUi

};

namespace Ui {
    class pageM: public Ui_pageM {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGEM_H

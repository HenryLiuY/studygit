/********************************************************************************
** Form generated from reading UI file 'TopPage.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOPPAGE_H
#define UI_TOPPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TopPage
{
public:
    QComboBox *leadsComboBox;
    QPushButton *current;
    QPushButton *archive;
    QLabel *wifiIcon;
    QLabel *label;
    QFrame *line;
    QWidget *widget_info;
    QLabel *label_4;
    QLineEdit *lineEdit;
    QLabel *label_5;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QToolButton *toolButton;
    QToolButton *toolButton_2;
    QComboBox *userComboBox;
    QLabel *label_6;

    void setupUi(QWidget *TopPage)
    {
        if (TopPage->objectName().isEmpty())
            TopPage->setObjectName(QStringLiteral("TopPage"));
        TopPage->resize(640, 98);
        TopPage->setMinimumSize(QSize(0, 0));
        TopPage->setStyleSheet(QLatin1String("background-color:  #383838;\n"
"border: none;"));
        TopPage->setProperty("AreaPos", QVariant(QPoint(0, 0)));
        leadsComboBox = new QComboBox(TopPage);
        leadsComboBox->setObjectName(QStringLiteral("leadsComboBox"));
        leadsComboBox->setGeometry(QRect(0, 0, 166, 56));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(leadsComboBox->sizePolicy().hasHeightForWidth());
        leadsComboBox->setSizePolicy(sizePolicy);
        leadsComboBox->setMinimumSize(QSize(166, 56));
        leadsComboBox->setSizeIncrement(QSize(0, 0));
        leadsComboBox->setBaseSize(QSize(166, 56));
        QFont font;
        leadsComboBox->setFont(font);
        leadsComboBox->setStyleSheet(QLatin1String("QComboBox{\n"
"	background-color: #383838;\n"
"	border: none;\n"
"	color: rgba(214, 214, 214, 0.8);\n"
"	padding-left: 13px;\n"
"	font-size: 14px;\n"
"}\n"
"\n"
"QComboBox::down-arrow{\n"
"	image: url(:/res/1-normal-off.png);\n"
"	border: none;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView::item{\n"
"	height: 42px;\n"
"	min-height: 42px;\n"
"	background-color: #383838;\n"
"	color: rgba(214, 214, 214, 0.8);\n"
"	padding-left: 10px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView::item:selected{\n"
"	height: 42px;\n"
"	min-height: 42px;\n"
"	background-color: rgba(120, 120, 120);\n"
"	color: #d6d6d6;\n"
"	border: none;\n"
"}\n"
"\n"
"QComboBox::drop-down{\n"
"	padding-right: 10px;\n"
"	width: 20px;\n"
"	border: none;\n"
"}\n"
"\n"
"\n"
""));
        leadsComboBox->setSizeAdjustPolicy(QComboBox::AdjustToContents);
        leadsComboBox->setIconSize(QSize(16, 16));
        current = new QPushButton(TopPage);
        current->setObjectName(QStringLiteral("current"));
        current->setGeometry(QRect(167, 0, 80, 56));
        current->setMinimumSize(QSize(80, 56));
        current->setSizeIncrement(QSize(0, 0));
        current->setFont(font);
        current->setStyleSheet(QLatin1String("QPushButton{\n"
"	border: none;\n"
"	color: #d6d6d6;\n"
"	background-color:  rgba(214, 214, 214, 0.12);\n"
"	font-size: 18px;\n"
"}"));
        archive = new QPushButton(TopPage);
        archive->setObjectName(QStringLiteral("archive"));
        archive->setGeometry(QRect(247, 0, 80, 56));
        archive->setMinimumSize(QSize(80, 56));
        archive->setFont(font);
        archive->setStyleSheet(QLatin1String("QPushButton{\n"
"	border: none;\n"
"	color: rgba(214, 214, 214);\n"
"	background-color: #383838;\n"
"	font-size: 14px;\n"
"}"));
        wifiIcon = new QLabel(TopPage);
        wifiIcon->setObjectName(QStringLiteral("wifiIcon"));
        wifiIcon->setGeometry(QRect(389, 12, 32, 32));
        wifiIcon->setPixmap(QPixmap(QString::fromUtf8(":/res/wifi1x.png")));
        label = new QLabel(TopPage);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(445, 12, 32, 32));
        label->setPixmap(QPixmap(QString::fromUtf8(":/res/battery-ok1x.png")));
        line = new QFrame(TopPage);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(499, 12, 3, 32));
        QPalette palette;
        QBrush brush(QColor(96, 96, 96, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        line->setPalette(palette);
        QFont font1;
        font1.setItalic(true);
        line->setFont(font1);
        line->setStyleSheet(QLatin1String("background-color: #606060;\n"
"\n"
""));
        line->setFrameShadow(QFrame::Plain);
        line->setFrameShape(QFrame::VLine);
        widget_info = new QWidget(TopPage);
        widget_info->setObjectName(QStringLiteral("widget_info"));
        widget_info->setGeometry(QRect(0, 57, 640, 40));
        widget_info->setStyleSheet(QLatin1String("QWidget{\n"
"	background-color: #2b2b2b;\n"
"}\n"
"\n"
"QLineEdit{\n"
"	color: white;\n"
"	font-size: 14px;\n"
"}\n"
"\n"
"QLabel{\n"
"	font-size: 14px;\n"
"}"));
        label_4 = new QLabel(widget_info);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(29, 11, 24, 24));
        label_4->setStyleSheet(QLatin1String("QLabel{\n"
"	background-image: url(:/res/patient-1x.png);\n"
"	background-repeat: no-repeat;\n"
"}"));
        lineEdit = new QLineEdit(widget_info);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(61, 9, 123, 24));
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QStringLiteral(""));
        label_5 = new QLabel(widget_info);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(184, 9, 41, 24));
        label_5->setFont(font);
        label_5->setStyleSheet(QLatin1String("QLabel{\n"
"	color: rgba(255, 255, 255, 0.6);\n"
"}"));
        lineEdit_2 = new QLineEdit(widget_info);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(222, 9, 98, 24));
        lineEdit_2->setFont(font);
        lineEdit_2->setStyleSheet(QStringLiteral(""));
        lineEdit_3 = new QLineEdit(widget_info);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(320, 9, 48, 24));
        lineEdit_3->setFont(font);
        lineEdit_3->setStyleSheet(QStringLiteral(""));
        lineEdit_4 = new QLineEdit(widget_info);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(374, 9, 60, 24));
        lineEdit_4->setFont(font);
        lineEdit_4->setStyleSheet(QStringLiteral(""));
        lineEdit_5 = new QLineEdit(widget_info);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(439, 9, 59, 24));
        lineEdit_5->setFont(font);
        lineEdit_5->setStyleSheet(QStringLiteral(""));
        toolButton = new QToolButton(widget_info);
        toolButton->setObjectName(QStringLiteral("toolButton"));
        toolButton->setGeometry(QRect(552, 11, 26, 24));
        toolButton->setStyleSheet(QLatin1String("	background-image: url(:/res/edit_normalx1.png);\n"
"	background-repeat: no-repeat;"));
        toolButton_2 = new QToolButton(widget_info);
        toolButton_2->setObjectName(QStringLiteral("toolButton_2"));
        toolButton_2->setGeometry(QRect(597, 11, 19, 19));
        toolButton_2->setStyleSheet(QLatin1String("	background-image: url(:/res/close_normalx1.png);\n"
"	background-repeat: no-repeat;"));
        userComboBox = new QComboBox(TopPage);
        userComboBox->setObjectName(QStringLiteral("userComboBox"));
        userComboBox->setEnabled(true);
        userComboBox->setGeometry(QRect(502, 0, 138, 56));
        sizePolicy.setHeightForWidth(userComboBox->sizePolicy().hasHeightForWidth());
        userComboBox->setSizePolicy(sizePolicy);
        userComboBox->setMinimumSize(QSize(138, 56));
        userComboBox->setMaximumSize(QSize(138, 56));
        userComboBox->setSizeIncrement(QSize(0, 0));
        userComboBox->setBaseSize(QSize(166, 56));
        userComboBox->setFont(font);
        userComboBox->setStyleSheet(QLatin1String("QComboBox{\n"
"	background-color: #383838;\n"
"	border: none;\n"
"	color: rgba(214, 214, 214, 0.8);\n"
"	padding-left: 42px;\n"
"	font-size: 12px;\n"
"}\n"
"\n"
"\n"
"QComboBox::down-arrow{\n"
"image: url(:/res/navigation1x.png);\n"
"	border: none;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView::item{\n"
"	height: 42px;\n"
"	min-height: 42px;\n"
"	background-color: #383838;\n"
"	color: rgba(214, 214, 214, 0.8);\n"
"	padding-left: 10px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView::item:selected{\n"
"	height: 42px;\n"
"	min-height: 42px;\n"
"	background-color: rgba(120, 120, 120);\n"
"	color: #d6d6d6;\n"
"	border: none;\n"
"}\n"
"\n"
"QComboBox::drop-down{\n"
"	border: none;\n"
"	padding-right: 8px;\n"
"	width:18;\n"
"}\n"
"\n"
"\n"
""));
        userComboBox->setSizeAdjustPolicy(QComboBox::AdjustToContents);
        userComboBox->setIconSize(QSize(16, 16));
        label_6 = new QLabel(TopPage);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(518, 12, 23, 32));
        label_6->setStyleSheet(QLatin1String("background-image: url(:/res/group-4-1x.png);\n"
"	background-repeat: no-repeat;\n"
"background-position:center;\n"
""));

        retranslateUi(TopPage);

        QMetaObject::connectSlotsByName(TopPage);
    } // setupUi

    void retranslateUi(QWidget *TopPage)
    {
        TopPage->setWindowTitle(QApplication::translate("TopPage", "Widget", Q_NULLPTR));
        TopPage->setProperty("Category", QVariant(QApplication::translate("TopPage", "top", Q_NULLPTR)));
        leadsComboBox->clear();
        leadsComboBox->insertItems(0, QStringList()
         << QApplication::translate("TopPage", "Standard 12 leads", Q_NULLPTR)
         << QApplication::translate("TopPage", "Standard 18 leads", Q_NULLPTR)
        );
        leadsComboBox->setCurrentText(QApplication::translate("TopPage", "Standard 12 leads", Q_NULLPTR));
        current->setText(QApplication::translate("TopPage", "Current", Q_NULLPTR));
        archive->setText(QApplication::translate("TopPage", "Archive", Q_NULLPTR));
        wifiIcon->setText(QString());
        label->setText(QString());
        label_4->setText(QString());
        lineEdit->setText(QApplication::translate("TopPage", "Monteorello, S.", Q_NULLPTR));
        label_5->setText(QApplication::translate("TopPage", "MRN", Q_NULLPTR));
        lineEdit_2->setText(QApplication::translate("TopPage", "3424-27843", Q_NULLPTR));
        lineEdit_3->setText(QApplication::translate("TopPage", "62yrs", Q_NULLPTR));
        lineEdit_4->setText(QApplication::translate("TopPage", "Female", Q_NULLPTR));
        lineEdit_5->setText(QApplication::translate("TopPage", "247 lbs", Q_NULLPTR));
        toolButton->setText(QString());
        toolButton_2->setText(QString());
        userComboBox->clear();
        userComboBox->insertItems(0, QStringList()
         << QApplication::translate("TopPage", "Dr.Brandon", Q_NULLPTR)
         << QApplication::translate("TopPage", "My account", Q_NULLPTR)
         << QApplication::translate("TopPage", "System setting", Q_NULLPTR)
         << QApplication::translate("TopPage", "Help", Q_NULLPTR)
         << QApplication::translate("TopPage", "Log out", Q_NULLPTR)
        );
        userComboBox->setCurrentText(QApplication::translate("TopPage", "Dr.Brandon", Q_NULLPTR));
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class TopPage: public Ui_TopPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOPPAGE_H

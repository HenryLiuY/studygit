/********************************************************************************
** Form generated from reading UI file 'QuicksetPage.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef QUICKSETPAGE_H
#define QUICKSETPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QuickSetPage
{
public:
    QTabWidget *tabWidget;
    QWidget *setting;
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QRadioButton *speed_5;
    QRadioButton *speed_10;
    QRadioButton *speed_25;
    QRadioButton *speed_50;
    QGroupBox *groupBox_3;
    QRadioButton *limbleads2_5;
    QRadioButton *limbleads5;
    QRadioButton *limbleads10;
    QRadioButton *limbleads20;
    QGroupBox *groupBox_4;
    QRadioButton *full;
    QRadioButton *half;
    QGroupBox *groupBox_5;
    QLabel *label;
    QLabel *label_2;
    QCheckBox *artifact;
    QCheckBox *wander;
    QGroupBox *groupBox_6;
    QLabel *label_3;
    QLabel *acFilter;
    QGroupBox *groupBox_7;
    QRadioButton *highpass005;
    QRadioButton *highpass015;
    QRadioButton *highpass05;
    QGroupBox *groupBox_8;
    QRadioButton *lowpass40;
    QRadioButton *lowpass100;
    QRadioButton *lowpass150;
    QGroupBox *groupBox_9;
    QRadioButton *pace_unknown;
    QRadioButton *nonpaced;
    QRadioButton *paced;
    QRadioButton *pacedMagnet;
    QWidget *format;
    QLabel *label_4;
    QWidget *analysis;
    QButtonGroup *LowPassGroup;
    QButtonGroup *HighPassGroup;
    QButtonGroup *LimbLeadsGroup;
    QButtonGroup *SpeedGroup;
    QButtonGroup *PacingGroup;
    QButtonGroup *ChestLeadsGroup;

    void setupUi(QWidget *QuickSetPage)
    {
        if (QuickSetPage->objectName().isEmpty())
            QuickSetPage->setObjectName(QStringLiteral("QuickSetPage"));
        QuickSetPage->resize(640, 369);
        QuickSetPage->setStyleSheet(QLatin1String("QWidget{\n"
"	background: rgba(150, 150, 150, 1);\n"
"}"));
        QuickSetPage->setProperty("AreaPos", QVariant(QPoint(0, 56)));
        tabWidget = new QTabWidget(QuickSetPage);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 640, 371));
        setting = new QWidget();
        setting->setObjectName(QStringLiteral("setting"));
        groupBox = new QGroupBox(setting);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 20, 261, 311));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(5, 30, 131, 191));
        speed_5 = new QRadioButton(groupBox_2);
        SpeedGroup = new QButtonGroup(QuickSetPage);
        SpeedGroup->setObjectName(QStringLiteral("SpeedGroup"));
        SpeedGroup->addButton(speed_5);
        speed_5->setObjectName(QStringLiteral("speed_5"));
        speed_5->setGeometry(QRect(20, 40, 115, 19));
        speed_5->setCheckable(true);
        speed_5->setChecked(false);
        speed_10 = new QRadioButton(groupBox_2);
        SpeedGroup->addButton(speed_10);
        speed_10->setObjectName(QStringLiteral("speed_10"));
        speed_10->setGeometry(QRect(20, 80, 115, 19));
        speed_25 = new QRadioButton(groupBox_2);
        SpeedGroup->addButton(speed_25);
        speed_25->setObjectName(QStringLiteral("speed_25"));
        speed_25->setGeometry(QRect(20, 120, 115, 19));
        speed_50 = new QRadioButton(groupBox_2);
        SpeedGroup->addButton(speed_50);
        speed_50->setObjectName(QStringLiteral("speed_50"));
        speed_50->setGeometry(QRect(20, 160, 115, 19));
        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(145, 30, 111, 191));
        limbleads2_5 = new QRadioButton(groupBox_3);
        LimbLeadsGroup = new QButtonGroup(QuickSetPage);
        LimbLeadsGroup->setObjectName(QStringLiteral("LimbLeadsGroup"));
        LimbLeadsGroup->addButton(limbleads2_5);
        limbleads2_5->setObjectName(QStringLiteral("limbleads2_5"));
        limbleads2_5->setGeometry(QRect(20, 40, 115, 19));
        limbleads5 = new QRadioButton(groupBox_3);
        LimbLeadsGroup->addButton(limbleads5);
        limbleads5->setObjectName(QStringLiteral("limbleads5"));
        limbleads5->setGeometry(QRect(20, 80, 115, 19));
        limbleads5->setCheckable(true);
        limbleads5->setChecked(false);
        limbleads10 = new QRadioButton(groupBox_3);
        LimbLeadsGroup->addButton(limbleads10);
        limbleads10->setObjectName(QStringLiteral("limbleads10"));
        limbleads10->setGeometry(QRect(20, 120, 115, 19));
        limbleads20 = new QRadioButton(groupBox_3);
        LimbLeadsGroup->addButton(limbleads20);
        limbleads20->setObjectName(QStringLiteral("limbleads20"));
        limbleads20->setGeometry(QRect(20, 160, 115, 19));
        groupBox_4 = new QGroupBox(groupBox);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(5, 230, 251, 71));
        full = new QRadioButton(groupBox_4);
        ChestLeadsGroup = new QButtonGroup(QuickSetPage);
        ChestLeadsGroup->setObjectName(QStringLiteral("ChestLeadsGroup"));
        ChestLeadsGroup->addButton(full);
        full->setObjectName(QStringLiteral("full"));
        full->setGeometry(QRect(20, 40, 81, 19));
        full->setCheckable(true);
        full->setChecked(false);
        half = new QRadioButton(groupBox_4);
        ChestLeadsGroup->addButton(half);
        half->setObjectName(QStringLiteral("half"));
        half->setGeometry(QRect(160, 40, 61, 19));
        groupBox_5 = new QGroupBox(setting);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(280, 20, 171, 91));
        label = new QLabel(groupBox_5);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 30, 72, 15));
        label_2 = new QLabel(groupBox_5);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 60, 61, 16));
        artifact = new QCheckBox(groupBox_5);
        artifact->setObjectName(QStringLiteral("artifact"));
        artifact->setGeometry(QRect(90, 30, 51, 23));
        wander = new QCheckBox(groupBox_5);
        wander->setObjectName(QStringLiteral("wander"));
        wander->setGeometry(QRect(90, 60, 41, 23));
        groupBox_6 = new QGroupBox(setting);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(460, 20, 161, 61));
        label_3 = new QLabel(groupBox_6);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 30, 72, 15));
        acFilter = new QLabel(groupBox_6);
        acFilter->setObjectName(QStringLiteral("acFilter"));
        acFilter->setGeometry(QRect(100, 30, 31, 16));
        groupBox_7 = new QGroupBox(setting);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        groupBox_7->setGeometry(QRect(460, 90, 161, 121));
        highpass005 = new QRadioButton(groupBox_7);
        HighPassGroup = new QButtonGroup(QuickSetPage);
        HighPassGroup->setObjectName(QStringLiteral("HighPassGroup"));
        HighPassGroup->addButton(highpass005);
        highpass005->setObjectName(QStringLiteral("highpass005"));
        highpass005->setGeometry(QRect(10, 30, 115, 19));
        highpass005->setCheckable(true);
        highpass005->setChecked(false);
        highpass015 = new QRadioButton(groupBox_7);
        HighPassGroup->addButton(highpass015);
        highpass015->setObjectName(QStringLiteral("highpass015"));
        highpass015->setGeometry(QRect(10, 60, 115, 19));
        highpass05 = new QRadioButton(groupBox_7);
        HighPassGroup->addButton(highpass05);
        highpass05->setObjectName(QStringLiteral("highpass05"));
        highpass05->setGeometry(QRect(10, 90, 115, 19));
        groupBox_8 = new QGroupBox(setting);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        groupBox_8->setGeometry(QRect(460, 220, 171, 111));
        lowpass40 = new QRadioButton(groupBox_8);
        LowPassGroup = new QButtonGroup(QuickSetPage);
        LowPassGroup->setObjectName(QStringLiteral("LowPassGroup"));
        LowPassGroup->addButton(lowpass40);
        lowpass40->setObjectName(QStringLiteral("lowpass40"));
        lowpass40->setGeometry(QRect(10, 30, 115, 19));
        lowpass40->setCheckable(true);
        lowpass40->setChecked(false);
        lowpass100 = new QRadioButton(groupBox_8);
        LowPassGroup->addButton(lowpass100);
        lowpass100->setObjectName(QStringLiteral("lowpass100"));
        lowpass100->setGeometry(QRect(10, 50, 115, 19));
        lowpass150 = new QRadioButton(groupBox_8);
        LowPassGroup->addButton(lowpass150);
        lowpass150->setObjectName(QStringLiteral("lowpass150"));
        lowpass150->setGeometry(QRect(10, 70, 115, 19));
        groupBox_9 = new QGroupBox(setting);
        groupBox_9->setObjectName(QStringLiteral("groupBox_9"));
        groupBox_9->setGeometry(QRect(280, 120, 171, 211));
        pace_unknown = new QRadioButton(groupBox_9);
        PacingGroup = new QButtonGroup(QuickSetPage);
        PacingGroup->setObjectName(QStringLiteral("PacingGroup"));
        PacingGroup->addButton(pace_unknown);
        pace_unknown->setObjectName(QStringLiteral("pace_unknown"));
        pace_unknown->setGeometry(QRect(20, 40, 115, 19));
        nonpaced = new QRadioButton(groupBox_9);
        PacingGroup->addButton(nonpaced);
        nonpaced->setObjectName(QStringLiteral("nonpaced"));
        nonpaced->setGeometry(QRect(20, 90, 115, 19));
        nonpaced->setCheckable(true);
        nonpaced->setChecked(false);
        paced = new QRadioButton(groupBox_9);
        PacingGroup->addButton(paced);
        paced->setObjectName(QStringLiteral("paced"));
        paced->setGeometry(QRect(20, 140, 115, 19));
        pacedMagnet = new QRadioButton(groupBox_9);
        PacingGroup->addButton(pacedMagnet);
        pacedMagnet->setObjectName(QStringLiteral("pacedMagnet"));
        pacedMagnet->setGeometry(QRect(20, 190, 115, 19));
        tabWidget->addTab(setting, QString());
        format = new QWidget();
        format->setObjectName(QStringLiteral("format"));
        label_4 = new QLabel(format);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(100, 90, 67, 17));
        tabWidget->addTab(format, QString());
        analysis = new QWidget();
        analysis->setObjectName(QStringLiteral("analysis"));
        tabWidget->addTab(analysis, QString());

        retranslateUi(QuickSetPage);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(QuickSetPage);
    } // setupUi

    void retranslateUi(QWidget *QuickSetPage)
    {
        QuickSetPage->setWindowTitle(QApplication::translate("QuickSetPage", "QuickSet", Q_NULLPTR));
        QuickSetPage->setProperty("Category", QVariant(QApplication::translate("QuickSetPage", "fnc", Q_NULLPTR)));
        groupBox->setTitle(QApplication::translate("QuickSetPage", "Report Scaling", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("QuickSetPage", "Speed", Q_NULLPTR));
        speed_5->setText(QApplication::translate("QuickSetPage", "5", Q_NULLPTR));
        speed_10->setText(QApplication::translate("QuickSetPage", "10", Q_NULLPTR));
        speed_25->setText(QApplication::translate("QuickSetPage", "25", Q_NULLPTR));
        speed_50->setText(QApplication::translate("QuickSetPage", "50", Q_NULLPTR));
        groupBox_3->setTitle(QApplication::translate("QuickSetPage", "Limb Leads", Q_NULLPTR));
        limbleads2_5->setText(QApplication::translate("QuickSetPage", "2.5", Q_NULLPTR));
        limbleads5->setText(QApplication::translate("QuickSetPage", "5", Q_NULLPTR));
        limbleads10->setText(QApplication::translate("QuickSetPage", "10", Q_NULLPTR));
        limbleads20->setText(QApplication::translate("QuickSetPage", "20", Q_NULLPTR));
        groupBox_4->setTitle(QApplication::translate("QuickSetPage", "Chest Leads", Q_NULLPTR));
        full->setText(QApplication::translate("QuickSetPage", "Full", Q_NULLPTR));
        half->setText(QApplication::translate("QuickSetPage", "Half", Q_NULLPTR));
        groupBox_5->setTitle(QApplication::translate("QuickSetPage", "Patient Filters", Q_NULLPTR));
        label->setText(QApplication::translate("QuickSetPage", "Artifact", Q_NULLPTR));
        label_2->setText(QApplication::translate("QuickSetPage", "Wander", Q_NULLPTR));
        artifact->setText(QApplication::translate("QuickSetPage", "OFF", Q_NULLPTR));
        wander->setText(QApplication::translate("QuickSetPage", "ON", Q_NULLPTR));
        groupBox_6->setTitle(QApplication::translate("QuickSetPage", "Default Filters", Q_NULLPTR));
        label_3->setText(QApplication::translate("QuickSetPage", "AC Filter", Q_NULLPTR));
        acFilter->setText(QApplication::translate("QuickSetPage", "50", Q_NULLPTR));
        groupBox_7->setTitle(QApplication::translate("QuickSetPage", "High Pass", Q_NULLPTR));
        highpass005->setText(QApplication::translate("QuickSetPage", "0.05", Q_NULLPTR));
        highpass015->setText(QApplication::translate("QuickSetPage", "0.15", Q_NULLPTR));
        highpass05->setText(QApplication::translate("QuickSetPage", "0.5", Q_NULLPTR));
        groupBox_8->setTitle(QApplication::translate("QuickSetPage", "Low Pass", Q_NULLPTR));
        lowpass40->setText(QApplication::translate("QuickSetPage", "40", Q_NULLPTR));
        lowpass100->setText(QApplication::translate("QuickSetPage", "100", Q_NULLPTR));
        lowpass150->setText(QApplication::translate("QuickSetPage", "150", Q_NULLPTR));
        groupBox_9->setTitle(QApplication::translate("QuickSetPage", "Pacing", Q_NULLPTR));
        pace_unknown->setText(QApplication::translate("QuickSetPage", "Paced Unknown", Q_NULLPTR));
        nonpaced->setText(QApplication::translate("QuickSetPage", "Non-paced", Q_NULLPTR));
        paced->setText(QApplication::translate("QuickSetPage", "Paced", Q_NULLPTR));
        pacedMagnet->setText(QApplication::translate("QuickSetPage", "Paced(magnet)", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(setting), QApplication::translate("QuickSetPage", "Setting", Q_NULLPTR));
        label_4->setText(QApplication::translate("QuickSetPage", "Format", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(format), QApplication::translate("QuickSetPage", "Format", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(analysis), QApplication::translate("QuickSetPage", "Analysis", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class QuickSetPage: public Ui_QuickSetPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // QUICKSETPAGE_H

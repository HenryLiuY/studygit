/********************************************************************************
** Form generated from reading UI file 'PatientPage.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef PATIENTPAGE_H
#define PATIENTPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PatientPage
{
public:
    QTabWidget *tabWidget;
    QWidget *tab;
    QFrame *frame_4;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QWidget *tab_3;
    QFrame *frame_3;
    QWidget *tab_4;
    QFrame *frame_2;
    QWidget *tab_2;
    QFrame *frame;

    void setupUi(QWidget *PatientPage)
    {
        if (PatientPage->objectName().isEmpty())
            PatientPage->setObjectName(QStringLiteral("PatientPage"));
        PatientPage->resize(640, 384);
        PatientPage->setWindowFlags(Qt::FramelessWindowHint);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(PatientPage->sizePolicy().hasHeightForWidth());
        PatientPage->setSizePolicy(sizePolicy);
        PatientPage->setStyleSheet(QLatin1String("QWidget{\n"
"	background-color: #171717;\n"
"	border: none;\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
""));
        PatientPage->setProperty("AreaPos", QVariant(QPoint(0, 56)));
        tabWidget = new QTabWidget(PatientPage);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 642, 386));
        tabWidget->setStyleSheet(QLatin1String("QWidget{\n"
"	background-color: #171717;\n"
"	border: none;\n"
"}\n"
"\n"
"\n"
"\n"
"QTabBar::tab{\n"
"	border: none;\n"
"	color: rgba(214, 214, 214, 0.8);\n"
"	max-width: 96px;\n"
"	min-width: 96px;\n"
"	max-height: 42px;\n"
"	min-height: 42px;\n"
"	font-size: 12px;\n"
"}\n"
"\n"
"\n"
"\n"
"QTabBar::tab:selected{\n"
"	color: rgba(214, 214, 214, 0.8);\n"
"	color: #d6d6d6;\n"
"	border-bottom: 2px solid;\n"
"	border-bottom-color: #d6d6d6;\n"
"}\n"
"\n"
"QFrame{\n"
"	background-color: rgba(255, 255, 255, 0.2);\n"
"}\n"
"\n"
"QLineEdit{\n"
"	border: 1px solid rgba(255, 255, 255, 0.3);\n"
"	max-width: 260px;\n"
"	min-width: 260px;\n"
"	max-height: 36px;\n"
"	min-height: 36px;	\n"
"	border-radius: 2px;\n"
"	background-color: rgba(5, 5, 5, 0.1);\n"
"	color: #d6d6d6;\n"
"	padding-left: 12px;\n"
"	font-size: 12px;\n"
"}\n"
"\n"
"QLabel{\n"
"	font-size: 12px;\n"
"	background-color: #171717;\n"
"	color: rgba(255, 255, 255, 0.5);\n"
"\n"
"}\n"
"\n"
"QScrollArea{\n"
"	background: transparent;\n"
"	min-height: 340px;\n"
"	m"
                        "ax-height: 340px;\n"
"}\n"
"\n"
"QScrollBar{\n"
"	background: transparent;\n"
"	background-color: #353535;	\n"
"}\n"
"\n"
"QScrollBar::handle{\n"
"	margin: 3px;\n"
"	border-radius: 4px; \n"
"	background-color: rgb(110, 110, 110);\n"
"}\n"
"\n"
"QScrollBar::add-line, QScrollBar::sub-line{\n"
"	border: none;\n"
"}\n"
""));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        frame_4 = new QFrame(tab);
        frame_4->setObjectName(QStringLiteral("frame_4"));
        frame_4->setGeometry(QRect(0, 0, 640, 1));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        scrollArea = new QScrollArea(tab);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setGeometry(QRect(0, 1, 640, 340));
        scrollArea->setWidgetResizable(true);
        scrollArea->setProperty("AreaPos", QVariant(QPoint(0, 56)));
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 640, 340));
        scrollArea->setWidget(scrollAreaWidgetContents);
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        frame_3 = new QFrame(tab_3);
        frame_3->setObjectName(QStringLiteral("frame_3"));
        frame_3->setGeometry(QRect(0, 0, 640, 1));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        frame_2 = new QFrame(tab_4);
        frame_2->setObjectName(QStringLiteral("frame_2"));
        frame_2->setGeometry(QRect(0, 0, 640, 1));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        tabWidget->addTab(tab_4, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        frame = new QFrame(tab_2);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(0, 0, 640, 1));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        tabWidget->addTab(tab_2, QString());

        retranslateUi(PatientPage);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(PatientPage);
    } // setupUi

    void retranslateUi(QWidget *PatientPage)
    {
        PatientPage->setWindowTitle(QApplication::translate("PatientPage", "Widget", Q_NULLPTR));
        PatientPage->setProperty("Category", QVariant(QApplication::translate("PatientPage", "fnc", Q_NULLPTR)));
        scrollArea->setProperty("Category", QVariant(QApplication::translate("PatientPage", "fnc", Q_NULLPTR)));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("PatientPage", "Add patient", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("PatientPage", "Worklist", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("PatientPage", "Find patient", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("PatientPage", "Edit patient", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class PatientPage: public Ui_PatientPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // PATIENTPAGE_H

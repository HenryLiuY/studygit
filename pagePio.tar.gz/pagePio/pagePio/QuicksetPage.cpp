#include "QuicksetPage.h"
#include <QVariant>
#include "UI_File/ui_TopPage.h"
#include "UI_File/ui_QuicksetPage.h"
#include "UI_File/ui_BtmPage.h"
#include "./include/pageManager/pagedef.h"
#include "./include/pageManager/pageManager.h"
#include <QPoint>
#include "./include/pageManager/widgetManager.h"
#include <QDebug>


QuickSetPage::QuickSetPage()
    :BasePage(stPage(WIDGET_DEF::TOP_MAINPAGE,
                     WIDGET_DEF::FNC_QUICKSET,
                     WIDGET_DEF::BTM_PATIENT))
{

    Factory<Ui::TopPage, Ui::QuickSetPage, Ui::BtmPage>().CombineWidget(this);

}


QuickSetPage::~QuickSetPage()
{
    qDebug() << "~QuickSetPage(): ======================size: " << WidgetManager::GetInstance()->getSize();
}



